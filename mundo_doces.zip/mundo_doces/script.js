// Confere se a quantidade digitada é válida.
function quantidadeValida() {
    let quantidade = Number(document.getElementById("quantidade").value);
    if (!Number.isInteger(quantidade) || quantidade < 1 || quantidade > 20) {
        alert("Digite uma quantidade de 1 a 20!");
        return null;
    }
    return quantidade;
}

function mostrarPedido(texto, quantidade, preco, nome) {
    document.getElementById("resultado").innerHTML = "<h3>" + nome + "</h3>" + texto;
    document.getElementById("total").textContent = "Total: " + (quantidade * preco).toLocaleString("pt-BR", {style:"currency",currency:"BRL"});
}

// FOR: adiciona balas.
function usarFor() {
    let quantidade = quantidadeValida();
    if (quantidade === null) return;
    let texto = "";
    for (let i = 1; i <= quantidade; i++) {
        texto += "🍬 ";
    }
    mostrarPedido(texto, quantidade, 2, "Suas balinhas 🍬");
}

// WHILE: adiciona pirulitos.
function usarWhile() {
    let quantidade = quantidadeValida();
    if (quantidade === null) return;
    let texto = "";
    let i = 1;
    while (i <= quantidade) {
        texto += "🍭 ";
        i++;
    }
    mostrarPedido(texto, quantidade, 3, "Seus pirulitos 🍭");
}

// DO...WHILE: adiciona cupcakes.
function usarDoWhile() {
    let quantidade = quantidadeValida();
    if (quantidade === null) return;
    let texto = "";
    let i = 1;
    do {
        texto += "🧁 ";
        i++;
    } while (i <= quantidade);
    mostrarPedido(texto, quantidade, 5, "Seus cupcakes 🧁");
}

function limpar() {
    document.getElementById("resultado").textContent = "Escolha um doce acima para começar 💕";
    document.getElementById("total").textContent = "";
    document.getElementById("quantidade").value = 5;
}
